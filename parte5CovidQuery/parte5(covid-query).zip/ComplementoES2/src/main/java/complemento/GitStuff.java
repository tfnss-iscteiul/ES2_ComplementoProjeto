package complemento;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.errors.AmbiguousObjectException;
import org.eclipse.jgit.errors.IncorrectObjectTypeException;
import org.eclipse.jgit.errors.RevisionSyntaxException;
import org.eclipse.jgit.lib.Constants;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.treewalk.filter.PathFilter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

/***
 * 
 * @author Hugo Cristino
 *
 */

public class GitStuff {

	private static Git git;
	private static String repo_URL;
	private static String repo_path;
	private static String file_name;
	private static Repository repo;
	private webForm_Xquery xq = new webForm_Xquery();

	public GitStuff() {
		this.file_name = "covid19spreading.rdf";
		this.repo_path = "src/main/resources";
		this.repo_URL = "https://github.com/vbasto-iscte/ESII1920.git";

	}
	
	public void response_html(String r , String i , String result) {
		
		String html = new String("<html> <body> <h1> Result the intended Fields </h1> "+ "<p1> Query para obter o numero de " + i + " no " + r + ": " + result + " </p1>" + "</body> </html> ") ;
		File resposta = new File("./reposta" +".html");
		try {
			resposta.createNewFile();
			FileUtils.writeStringToFile(resposta,html, "UTF-8");
			FileUtils.openInputStream(resposta);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/***
	 * this method clones the repository where the files that are need from the
	 * project are
	 */
	private void clone_repository() {

		try {
			git = Git.cloneRepository().setURI(repo_URL).setDirectory(new File(repo_path)).call();
		} catch (InvalidRemoteException e) {
			e.printStackTrace();
		} catch (TransportException e) {
			e.printStackTrace();
		} catch (GitAPIException e) {
			e.printStackTrace();
		}

	}

	/***
	 * opens the repository that was cloned
	 */

	private void open_repo() {
		try {
			git = Git.open(new File(repo_path));
			repo = git.getRepository();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/***
	 * initializes the base for the project
	 */

	private void initialization() {
		if (!(new File(repo_path).exists())) {
			clone_repository();
		} else {
			open_repo();
			check_lastCommit();
		}
	}

	/***
	 * checks for the last commit of covid19spreading.rdf
	 */
	private void check_lastCommit() {

		try {
			ObjectId lastcommit = repo.resolve(Constants.HEAD);

			RevWalk revWalk = new RevWalk(repo);

			RevCommit commit = revWalk.parseCommit(lastcommit);

			RevTree revTree = commit.getTree();

			TreeWalk treeWalk = new TreeWalk(repo);

			treeWalk.addTree(revTree);
			treeWalk.setRecursive(true);
			treeWalk.setFilter(PathFilter.create(file_name));

			if (!treeWalk.next()) {
				throw new IllegalStateException("There is no file on this path");
			}

			treeWalk.getObjectId(0);

		} catch (RevisionSyntaxException e) {
			e.printStackTrace();
		} catch (AmbiguousObjectException e) {
			e.printStackTrace();
		} catch (IncorrectObjectTypeException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/***
	 * creates the webform
	 */
	private void formulario() {

		String html = new String("<html> <body> <h1> Select the intended Fields </h1> " + "<form>"
				+ "  <label for=\"Regiao\">Select a Region:</label>" + " <select name=\"Regiao\" id=\"Regiao\">"
				+ " <option value=\" " + xq.getElements_Regioes().get(0) + "\">" + xq.getElements_Regioes().get(0)
				+ "</option>" + " <option value=\" " + xq.getElements_Regioes().get(1) + "\">"
				+ xq.getElements_Regioes().get(1) + "</option>" + " <option value=\" " + xq.getElements_Regioes().get(2)
				+ "\">" + xq.getElements_Regioes().get(02) + "</option>" + " <option value=\" "
				+ xq.getElements_Regioes().get(3) + "\">" + xq.getElements_Regioes().get(03) + "</option>"
				+ " <option value=\" " + xq.getElements_Regioes().get(4) + "\">" + xq.getElements_Regioes().get(04)
				+ "</option>" + "</select>" + "<br><br>"

				+ "<form>\r\n" + "  <label for=\"Informacaoo\">Select the Information:</label>"
				+ " <select name=\"Informacao\" id=\"Informacao\">" + " <option value=\" "
				+ xq.getElements_DataProperties().get(0) + "\">" + xq.getElements_DataProperties().get(0) + "</option>"
				+ " <option value=\" " + xq.getElements_DataProperties().get(1) + "\">"
				+ xq.getElements_DataProperties().get(1) + "</option>" + " <option value=\" "
				+ xq.getElements_DataProperties().get(2) + "\">" + xq.getElements_DataProperties().get(02) + "</option>"
				+ "</select>" + "<br><br>" + "<input type=\"submit\" value=\"Submit\">" + "</body></html> ");
		File f = new File("./file" + ".html");

		try {
			f.createNewFile();

			FileUtils.writeStringToFile(f, html, "UTF-8");
			FileUtils.openInputStream(f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	


	public static void main(String[] args) {
		webForm_Xquery n = new webForm_Xquery();
		n.getElements_Regioes();
		n.getElements_DataProperties();
		
		GitStuff g = new GitStuff();
		g.initialization();
		g.formulario();
		
		n.response();
	}

}
