package complemento;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

/***
 * 
 * @author Hugo Cristino n�77825
 *
 */
public class webForm_Xquery {

	private static String file_path = "src/main/resources/";
	private static String file_name = "covid19spreading.rdf";
	private static List<String> Regioes;
	private static List<String> dataProperties;
	private List<String> temp1 = new ArrayList<String>();

	public webForm_Xquery() {
		this.Regioes = new ArrayList<String>();
		this.dataProperties = new ArrayList<String>();
	}

	/***
	 * 
	 * @return a list with all the regions
	 */
	public static List<String> getRegioes() {
		return Regioes;
	}

	/***
	 * 
	 * @return a list with all the properties
	 */
	public static List<String> getDataProperties() {
		return dataProperties;
	}

	/***
	 * 
	 * @return the list with all regions from the covid19spreading.rdf file
	 */
	public List<String> getElements_Regioes() {
		try {
			File inputFile = new File(file_path + file_name);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();

			String query1 = "/RDF/NamedIndividual/@*";
			// System.out.println("Query para obter a lista das regi�es: ");
			XPathFactory xpathFactory = XPathFactory.newInstance();
			XPath xpath = xpathFactory.newXPath();
			XPathExpression expr = xpath.compile(query1);
			NodeList nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
			for (int i = 0; i < nl.getLength(); i++) {
				temp1.add(StringUtils.substringAfter(nl.item(i).getNodeValue(), "#"));

			}
			// System.out.println(temp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Regioes.addAll(temp1);
		return Regioes;
	}

	/***
	 * 
	 * @return all the properties from the covid19spreading.rdf
	 */

	public List<String> getElements_DataProperties() {
		temp1.clear();
		try {
			File inputFile = new File(file_path + file_name);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();

			String query1 = "/RDF/DatatypeProperty/@*";
			// System.out.println("Query para obter a lista das Properties: ");
			XPathFactory xpathFactory = XPathFactory.newInstance();
			XPath xpath = xpathFactory.newXPath();
			XPathExpression expr = xpath.compile(query1);
			NodeList nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
			for (int i = 0; i < nl.getLength(); i++) {
				temp1.add(StringUtils.substringAfter(nl.item(i).getNodeValue(), "#"));

			}
			// System.out.println(temp1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		dataProperties.addAll(temp1);
		return dataProperties;
	}
	
	public void response() {
		String r = new String();
		String i = "";
		try {
			Scanner s = new Scanner(new File("./fileTest.txt"));
			while(s.hasNextLine()) {
				r=s.next();
				i=s.next();
			}
			filterResponse(r, i);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void filterResponse(String region, String info) {
		try {
			File inputFile = new File(file_path + file_name);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();

			String query = "/RDF/NamedIndividual/@*";
			XPathFactory xpathFactory = XPathFactory.newInstance();
			XPath xpath = xpathFactory.newXPath();
			XPathExpression expr = xpath.compile(query);
			NodeList nl = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
			for (int i = 0; i < nl.getLength(); i++) {
				//System.out.println(StringUtils.substringAfter(nl.item(i).getNodeValue(), "#"));
			}

			query = "//*[contains(@about,'"+ region + "')]/"+ info + "/text()";
			//System.out.println("Query para obter o numero de " + info + " no " + region + ": " );
			expr = xpath.compile(query);
			System.out.println("Query para obter o numero de " + info + " no " + region + ": " + expr.evaluate(doc, XPathConstants.STRING));
			
			GitStuff g = new GitStuff();
			g.response_html(region, info ,(String) expr.evaluate(doc, XPathConstants.STRING));
		} catch (Exception e) {
			e.printStackTrace();
		
		}
		
	
		
	}


}
