package tests;

import static org.junit.Assert.*;
import complemento.*;
import org.junit.Test;
import complemento.GitStuff;
public class Complemento_testes {

	@Test
	public void test_dataproperties() {
		webForm_Xquery n = new webForm_Xquery();
		n.getElements_DataProperties();
		
	}
	
	@Test
	public void test_regiao() {
		webForm_Xquery n = new webForm_Xquery();
		n.getElements_Regioes();
		
	}
	
	@Test
	public void test_getDataproperties() {
		webForm_Xquery n = new webForm_Xquery();
		n.getDataProperties();
		
	}
	@Test
	public void test_getRegion() {
		webForm_Xquery n = new webForm_Xquery();
		n.getRegioes();
		
	}
	
	@Test
	public void test_CloneRepository (){
		GitStuff g = new GitStuff();
		g.main(null);
		
	}

}
