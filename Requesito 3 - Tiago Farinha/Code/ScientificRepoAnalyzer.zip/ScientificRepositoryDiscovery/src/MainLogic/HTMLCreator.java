package MainLogic;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import pl.edu.icm.cermine.metadata.model.DateType;
import pl.edu.icm.cermine.metadata.model.DocumentAuthor;
import pl.edu.icm.cermine.metadata.model.DocumentMetadata;

/**
 * Global Metadata Container Thread, that initializes Extractor threads, holds
 * all the information and saves it to an HTML File.
 * 
 * @author Tiago Farinha
 * @version 1.0
 * 
 */
public class HTMLCreator extends Thread {

	/** Number of article being added to HTML page. */
	private int articleID;

	/** HTML File to receive data. */
	private File file;

	/** Temporary document that holds all the information to save. */
	private Document doc;

	/**
	 * HTMLCreator constructor. Creates a new instance of a HTMLCreator.
	 * 
	 * @param path Path where the final file shall be created.
	 */
	public HTMLCreator(String path) {
		try {
			createFile(path);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Creates a new file, and initiates a new document with the static part of the
	 * HTML page.
	 * 
	 * @param path Path to the file being created.
	 * 
	 * @throws IOException If the file couldn't be created. Checked in the
	 *                     constructor method.
	 */
	private void createFile(String path) throws IOException {
		file = new File(path);

		if (file.exists())
			file.delete();

		file.createNewFile();

		doc = Jsoup.parse("<!DOCTYPE html> <html lang=\"en\"> <head> <meta charset=\"UTF-8\">"
				+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
				+ "    <title>Artigos</title>" + "</head>" + "<body>" + ""
				+ "    <table id = \"table\" style=\"width:100%\">" + "      <tr>" + "        <th>Article Title</th>"
				+ "        <th>Journal Name</th> " + "        <th>Publication Year</th>" + "        <th>Authors</th>"
				+ "      </tr>");
	}

	/**
	 * Creates a Extractor thread to each file found, waits for them all to
	 * terminate and saves all information extracted to a file.
	 */
	@Override
	public void run() {
		try {
			System.out.println("A carregar ficheiros pdf...");

			ArrayList<MetadataExtractor> threads = new ArrayList<>();

			File articleFiles = new File("articles");
			for (File f : articleFiles.listFiles())
				threads.add(new MetadataExtractor(f.getName(), new FileInputStream(f), this));

			for (Thread t : threads)
				t.start();

			for (Thread t : threads)
				t.join();

			saveToFile();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Erro ao salvar ficheiro");
		}
	}

	/**
	 * Saves the current information present in the Document to a local HTML file.
	 * 
	 * @throws IOException If the file couldn't be written. Checked in the run
	 *                     method.
	 */
	private void saveToFile() throws IOException {
		FileUtils.writeStringToFile(file, doc.outerHtml(), "UTF-8");
		System.out.println(doc.outerHtml());
		System.out.println("Ficheiro salvo com sucesso");
	}

	/**
	 * Called everytime an Extractor finishes extracting. Adds the information
	 * extracted to the current document.
	 * 
	 * @param meta     Metadata information extracted from file.
	 * @param fileName Name of the file analyzed.
	 */
	public synchronized void addToDoc(DocumentMetadata meta, String fileName) {
		String title, journal, pubYear, authors = "";

		title = meta.getTitle();
		journal = meta.getJournal();
		pubYear = meta.getDate(DateType.PUBLISHED).getYear();

		for (DocumentAuthor x : meta.getAuthors())
			authors += x.getName() + ", ";

		Element table = doc.getElementById("table");

		table.append("<tr><td><a target=\"_blank\" href='http://192.168.99.100/wp-content/uploads/simple-file-list/"
				+ fileName + "'>" + title + "</a></td> <td>" + journal + "</td> <td>" + pubYear + "</td> <td>"
				+ authors.replaceAll(", $", "") + "</td> </tr>");

		System.out.println("Artigo adicionado ao documento HTML. ID: " + ++articleID);
	}
}