package MainLogic;

/**
 * Java Application to get metadata from pdf files and populate a HTML page.
 * 
 * @author Tiago Farinha
 * @version 1.0
 * 
 */
public class IntegrationAppLauncher {

	/**
	 * Starts main coordinator thread that handles all files and measures operation
	 * time
	 * 
	 * @param args List of arguments to execute the program. Should receive path of
	 *             the file to be created.
	 */
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		try {
			HTMLCreator xc = new HTMLCreator(args[0]);
			xc.start();
			xc.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Tempo decorrido: " + (double) (System.currentTimeMillis() - startTime) / 1000d + "s");
	}
}
