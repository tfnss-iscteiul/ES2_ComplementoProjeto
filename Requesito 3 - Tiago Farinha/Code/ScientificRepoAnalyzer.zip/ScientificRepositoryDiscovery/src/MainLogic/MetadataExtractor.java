package MainLogic;

import java.io.FileInputStream;

import pl.edu.icm.cermine.ContentExtractor;

/**
 * Thread responsible for retrieving metadata from one file and add the
 * information to a global metadata information container.
 * 
 * @author Tiago Farinha
 * @version 1.0
 * 
 */
public class MetadataExtractor extends Thread {

	/** File stream to extract information from. */
	private FileInputStream f;

	/** Instance to the global metadata container */
	private HTMLCreator creator;

	/** Name of file being analyzed */
	private String fileName;

	/**
	 * Creates a new MetadaExtractor thread to extract information from a certain
	 * file
	 * 
	 * @param fileName Name of file being analyzed
	 * @param f        File to extract information from.
	 * @param creator  Instance to the global metadata container.
	 */
	public MetadataExtractor(String fileName, FileInputStream f, HTMLCreator creator) {
		this.fileName = fileName;
		this.f = f;
		this.creator = creator;
	}

	/**
	 * Extracts metadata from a file and adds that information to the main
	 * container.
	 */
	@Override
	public void run() {
		ContentExtractor extractor;
		try {
			extractor = new ContentExtractor();
			extractor.setPDF(f);

			creator.addToDoc(extractor.getMetadata(), fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
