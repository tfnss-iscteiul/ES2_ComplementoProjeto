package Tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;

import org.junit.jupiter.api.Test;

import MainLogic.IntegrationAppLauncher;

class MainTests {
	private String path = "scientific.html";

	@Test
	void testProgramRun() {
		assertDoesNotThrow(() -> IntegrationAppLauncher.main(new String[] { path }));
	}

	@Test
	void testFinalFileCreated() {
		assertTrue(new File(path).exists());
	}

}
