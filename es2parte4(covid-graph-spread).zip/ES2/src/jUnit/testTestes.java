package jUnit;

import main.*;
import org.junit.jupiter.api.Test;

class testTestes {

	@Test
	void test() {
		test t = new test();
	}

}
