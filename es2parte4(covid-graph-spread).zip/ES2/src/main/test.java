package main;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.commons.io.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.ListTagCommand;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.errors.RevisionSyntaxException;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.PersonIdent;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.treewalk.filter.PathFilter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class test {

	
	private ArrayList<String> timeStamp = new ArrayList<>(), fileName = new ArrayList<>(), fileTag = new ArrayList<>(),
			tagDescription = new ArrayList<>(), commitList = new ArrayList<>();

	public test() {
		git();
		table();
	}

	/**
	 * ligacao ao git e retirar informacao para adicionar a tabela
	 *
	 * @throws IllegalStateException se nao tiver ficheiro com o filtro
	 */
	private void git() {
		try {
			File dir = new File("./new");
			Git git;
			if (!dir.exists()) {
				git = Git.cloneRepository().setURI("https://github.com/vbasto-iscte/ESII1920").setDirectory(dir).call();
			} else {
				git = Git.open(dir);
			}

			ArrayList<ObjectId> objID = new ArrayList<>();
			ListTagCommand test = git.tagList();
			String[] tagName;
			for (Ref objectId : test.call()) {
				tagName = objectId.getName().split("/");
				fileTag.add(tagName[2]);
				objID.add(objectId.getObjectId());
			}

			for (ObjectId current : objID) {
				RevWalk revWalk = new RevWalk(git.getRepository());

				RevCommit commit = revWalk.parseCommit(current);

				RevTree revTree = commit.getTree();
								
				PersonIdent author = commit.getAuthorIdent();
				
				
				TreeWalk treeWalk = new TreeWalk(git.getRepository());
				
				
				
				treeWalk.addTree(revTree);
				treeWalk.setRecursive(true);
				treeWalk.setFilter(PathFilter.create("covid19spreading.rdf"));
							
				if(!treeWalk.next())
					throw new IllegalStateException("no file");


				
				timeStamp.add(author.getWhen().toString());
				fileName.add(treeWalk.getPathString());
				tagDescription.add(commit.getFullMessage());
				commitList.add(commit.getName()+"/"+treeWalk.getPathString());
				
			}
						
		} catch (GitAPIException | RevisionSyntaxException | IOException e) {

			e.printStackTrace();
		}
	}

	/**
	 * Criacao da tabela html
	 *
	 */
	private void table() {
		String link = null;
		File file = new File("./file.html");
		try {
			file.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		String html = "<html><head><title>Test</title></head>" + "<body>"
				+ "<div id='table'><a id='' href=''></a></div>" + "</body></html>";
		
		Document document = Jsoup.parse(html);
		Element div = document.getElementById("table");

		div.html("<table id=test style=\"width:100%\">" + "<tr>" + "<th> File timestamp</th>" + "<th>File name</th>"
				+ "<th>File tag</th>" + "<th>Tag Description</th>" + "<th>Spread Visualization Link</th>");
		
		Element div2 = document.getElementById("test");
		
		for (int i = 0; i < timeStamp.size(); i++) {
			link = "http://visualdataweb.de/webvowl/#iri=https://github.com/vbasto-iscte/ESII1920/raw/"
					+commitList.get(i);
			div2.append("<tr>" + "<td>" + timeStamp.get(i) + "</td>" + "<td>" + fileName.get(i) + "</td>" 
					+ "<td>" + fileTag.get(i) + "</td>" + "<td>" + tagDescription.get(i) + "<td <a href= " + 
					link + ">"+ ">" + link + "</td>"
					+ "</tr>");
		}
		try {
			FileUtils.writeStringToFile(file, document.outerHtml(), "UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		test t = new test();
	}
}
